"""MeshCore Pi Station."""

__version__ = "0.6.0"
